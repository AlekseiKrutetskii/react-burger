import {
    order
} from './order'

describe('orderSlice', () => {
    describe('reducers', () => {
        const initialState = {
            order: null,
            loading: 'idle'
        }
        it('test initialState order', () => {
            expect(order.reducer(undefined, {type: ''})).toEqual(initialState);
        });
    });
});